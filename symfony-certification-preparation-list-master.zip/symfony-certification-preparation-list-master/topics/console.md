[Back to index](../readme.md#table-of-contents)

# Console
- [The Console Component - symfony.com](http://symfony.com/doc/3.0/components/console.html)

## Built-in commands

## Custom commands
- [Console Commands - symfony.com](http://symfony.com/doc/3.0/console.html)

## Configuration

## Options and arguments
- [Console Input (Arguments & Options)](https://symfony.com/doc/3.0/console/input.html)

## Input and Output objects

## Built-in helpers
- [The Console Helpers - symfony.com](https://symfony.com/doc/3.0/components/console/helpers/index.html)

## Console events

## Verbosity levels
- [Verbosity levels](https://symfony.com/doc/3.0/console/verbosity.html)
