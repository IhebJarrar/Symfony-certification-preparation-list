[Back to index](../readme.md#table-of-contents)

# Miscellaneous

## Error handling
- [How to Customize Error Pages - symfony.com](http://symfony.com/doc/3.0/controller/error_pages.html)

## Code debugging
- [The Debug Component - symfony.com](http://symfony.com/doc/3.0/components/debug.html)

## Deployment best practices

## Process and Serializer components

## Data collectors

## Web Profiler and Web Debug Toolbar

## Internationalization and localization